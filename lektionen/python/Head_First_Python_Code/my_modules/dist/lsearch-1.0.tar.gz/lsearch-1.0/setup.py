from setuptools import setup

setup(
  name = 'lsearch',
  version = '1.0',
  description = 'The Head First Python Search Tools',
  author = 'Zhadox',
  author_email = 'nlorax@gmail.com',
  url = 'headfirstlabs.com',
  py_modules = ['lsearch'],
  )

